#include <iostream>        // <stdio.h> <stdlib.h> <string.h> already included somewhere in fl*.h
#include <fstream>         // c++ i/o in write_opts()

#include <algorithm>       // std::sort
#include <bits/stdc++.h>   // sort opt_s
#include <sys/types.h>     // stat
#include <sys/stat.h>      // stat
#include <unistd.h>        // stat, chdir, unlink
#include <regex.h>         // used in tylo-opts.h
#include <vector>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Browser.H>
#include <FL/Fl_Text_Editor.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/Fl_Menu_Bar.H>
#include <FL/Fl_Hold_Browser.H>
#include <FL/fl_ask.H>

#if __cplusplus >= 201703
   #define HAVEFS
   #include <filesystem>      // file status in save()
#endif

using std::vector;
using std::string;
using std::cout;
using std::cerr;
using std::endl;
using std::sort;
using std::fstream;

#define APPTTL    "Tylosaurus"
#define APPVER    "version alpha-116"

#define TMPLTFL   "tylo-tmplts.txt"
#define GAMEFL    "tylo-games.txt"
#define HELPFL    "tylo-help.txt"
#define CSTMFL    "user-misc.txt"

#define LBLH      36             // pixel height, label across top of window

#define MAXQT     999            // max quantity for tile cnt (etc.)
#define BRDMAX    32             // board size - square root of the count of the majority of widgets on screen. must not be too big.
#define RCKMAX    32             // shrug
#define ALPHAMAX  37             // based on the scientific estimate of how big of a bag display will fit on my screen
#define TBLSMAX   16             // max number of templates / tables
#define COLSEP    '\t'           // column separator for the browser columns

// chars in line in tmplt file: 3 (brdn|) + 3 (rckn|) + 3 (alphan|) + 33 (opponent name|) + alphamax * 20 (alpha descriptions) + brdmax^2*4+1 (colors|)
#define TMPLTMAX  3 + 3 + 3 + 33 + ALPHAMAX * 20 + (BRDMAX * BRDMAX * sizeof("ffff") - 1) + 1
#define OPPMAX    32
#define FLLRCHR   ' '            // char for blank brd/rck cell (not blank tile)
#define FLLRLBL   " "
#define NTSNL     '\1'           // subststitute for \n in notes on disk
#define GSACTV    '1'            // game statuses in game_s and corresponding format codes for menu item
#define ACTVCD    "@b"
#define GSOVER    '0'
#define OVERCD    "@C46@."
#define TIMEFMT   "%y-%m-%d %H:%M:%S"              // fmt string for strptime()
#define TIMESZ    sizeof("21-01-19 10:42:42")      // fmt as it appears in game file
#define NTSMAX    1024                             // notes, max chars. not enforced except when reading & writing game file
#define GMMAX     1 /* status */ + TMPLTMAX + 1 + OPPMAX + 1 + TIMESZ * 2 + BRDMAX * BRDMAX + 1 + RCKMAX + 1 + NTSMAX

// these pixel dims for the bag area are mostly based on trial and error and just work
#define VISPIX    16       // visible symbol (mostly aka "the letter")
#define PVPIX     20       // point value
#define PVVPIX    8        // vertical pix for subscripted point value (cellpix / 3 for the moment)
#define REMPIX    24       // remaining qt
#define GVNPIX    36       // given qt - needs room for leading '/'

#define cc        const char           // conveniences
#define uint      unsigned int
#define nt        (std::nothrow)
#define STS(n)    (std::to_string(n))
#define I2CS(n)   (STS(n).c_str())

#define EOOM(o)         cout << "Out of memory for " << o << ", " __FILE__ << ":" << __LINE__, exit(EXIT_FAILURE)
#define EINIT(msg)      fl_alert("%s can't load because\n%s", self, msg), throw(EXIT_FAILURE)
#define EOPT(opt, msg)  fl_alert("%s can't load because\noption %s %s (internal error).", self, opt.c_str(), msg), throw(EXIT_FAILURE)
#define EGAME(msg)      throw(msg)
enum { EVNOTHANDLED, EVHANDLED };

class Msg;
class BRcell;
class Brdcell;
class Rckcell;
class Notes;
class Tbl;
class Brwsr;
class App;


//enum sec { SEC_BRW, SEC_BRD, SEC_RCK, SEC_NTS, SEC_BAG }; // enum for sections. not yet in use.

// game_s: has a text buffer instead of raw text to obviate the need to realloc for changing sizes of char[]

struct game_s     { Tbl *tbl; char stat, *opp, *brd, *rck; Fl_Text_Buffer *buffy; string fmtd, starttm, endtm; };
struct cur_s      { Tbl *tbl = NULL; game_s *game = NULL; int ntbls = 0, ngames = 0, nactv = 0; bool mod; } cur;
struct alpha_s    { int kystrk; char *clp, *vis; short bagrow; char pointv, given, isvwl; };
struct tblinfo_s  { int brdn, rckn, alphan; string name, misc; };

void     app_active     (App*, bool);
void     app_cb         (Fl_Widget*, void*);
void     brwsr_cb       (Fl_Widget *);
bool     check_isreg    (cc*, bool);
int      getiopt        (string);
string   getsopt        (string);
void     load_game      (game_s*);
void     mk_fmtd_text   (game_s*);
void     mk_tilestr     (game_s*, cc*, cc*);
int      notes_handle   (Notes*, int);
void     notesmod_cb    (int, int nInserted, int nDeleted, int, const char*, void* v);
void     parse_arg0     (char*);
int      qcmp           (const void *rec1, const void *rec2) { return ((alpha_s*) rec1)->kystrk - ((alpha_s*) rec2)->kystrk; }      // for qsort
bool     read_games     (App*);
void     read_opts      ();
bool     read_tbl_info  (vector <tblinfo_s> &);
void     setmod         (App*, bool);
int      try_squish     (int, int);
alpha_s* srch_keytab    (alpha_s*, int, int);
void     unload_game    (bool);
void     update_cnts    (Tbl*, alpha_s*, alpha_s*);
void     write_opts     (App*);

#define MCB_ARGS     Fl_Widget *w, void *v      // menu callbacks for the user and a few wrappers for the app
#define MCBAPP_DECL  App *app = ((App *) v)
#define MCBMENU_DECL Fl_Menu_Bar *menu = ((Fl_Menu_Bar *) w)

void  clear          (App*);                    // the wrappers are for when a function needs to be called without using shortcut keypress or menu click
void  clear_mcb      (MCB_ARGS);
void  cstm_mcb       (MCB_ARGS);
void  copyto_mcb     (MCB_ARGS);
void  delete_mcb     (MCB_ARGS);
void  find_symb      (string);
void  find_mcb       (MCB_ARGS);
void  find_reset     ();
void  find_reset_mcb (MCB_ARGS);
void  game_over_mcb  (MCB_ARGS);
void  help_mcb       (MCB_ARGS);
void  new_mcb        (MCB_ARGS);
void  new_game       (MCB_ARGS, bool);
void  quit           (App*);
void  quit_mcb       (MCB_ARGS);
void  rematch_mcb    (MCB_ARGS);
void  rename_mcb     (MCB_ARGS);
void  save_mcb       (MCB_ARGS);
void  save           (App*);
void  sort_mcb       (MCB_ARGS);
void  sort_brwsr     (App*, string);
bool  by_name        (game_s*, game_s*);
bool  by_start       (game_s*, game_s*);
bool  by_end         (game_s*, game_s*);
bool  by_stat_by_name(game_s*, game_s*);
void  squish_mcb     (MCB_ARGS);

char *home, *self;      // home for chdir(); self for error msgs

class Numcell : public Fl_Box {     // label for this class is arbitrary text followed by a mathematically manipulatable integer represented as text.
   public:                          // It bypasses the several problems using an output box, the worst of which is that you cant set the alignment
                                    // or the font of its value(). Also there is no output box that uses int internally, only double or nonnumeric.
   #define NCTXTMAX 27              // total max will equal this #define + space + next #define + nul.
   #define NCDGTMAX 4               // compiler complains if number of digitd isn't 4

   char val, *valptr, fulllbl[NCTXTMAX + NCDGTMAX + 2] = { 0 };

   Numcell(int x, int y, int w, int cellpix, cc *lbl, char v = 0) : Fl_Box(x, y, w, cellpix, 0) {
      box(FL_FLAT_BOX);
      color(getiopt("stat_bg"));
      labelcolor(getiopt("stat_fg"));
      labelfont(FL_COURIER);
      labelsize(getiopt("stat_fs"));
      align(FL_ALIGN_LEFT | FL_ALIGN_INSIDE);
      label(fulllbl);
      text(lbl, v);
   }
   void text(cc *s, char j = 0) {            // string "bag" is assigned at tbl::addobjects, string game->opp at load_game()
      int valoff;
      if((valoff = strlen(s)) > NCTXTMAX)
         valoff = NCTXTMAX;
      valptr = (char *) fulllbl + valoff + 1;            // +1 for the space
      val = j;
      snprintf(fulllbl, NCTXTMAX + NCDGTMAX - 1, "%.*s %d", NCTXTMAX, s, j);
   }
   int   value()        { return atoi(valptr); }
   void  value(char j)  { snprintf(valptr, NCDGTMAX, "%d", val  = j); this->redraw(); }   // write arbitrary value at appropriate offset
   void  incr(char j)   { snprintf(valptr, NCDGTMAX, "%d", val += j); this->redraw(); }   // increment (or decr) val "  "  "
};
class Bagrow: public Fl_Group {
   public:
   string symb;
   
   Bagrow(int x, int y, int w, int h, string s) : Fl_Group(x, y, w, h) {
      symb = s;
      end();
   }
   int handle(int e) {
      if(e == FL_PUSH) {         // dont need a shortcut but maybe have one anyway?
         find_symb(symb);
         return EVHANDLED;
      }
      return EVNOTHANDLED;
   }
};
class Bagcell: public Fl_Box {   // used by bag components
   public:

   Bagcell(int x, int y, int w, int cellpix, int lblsz, const Fl_Align& just, cc *lbl) : Fl_Box(x, y, w, cellpix) {
      box(FL_FLAT_BOX);                labelfont(FL_COURIER);
      labelsize(lblsz);                color(getiopt("bag_bg"));
      labelcolor(getiopt("bag_posi")); align(just | FL_ALIGN_INSIDE);
      copy_label(lbl);
   }
};
class BRcell : public Fl_Box {
   public:
   char kystrk = FLLRCHR;
   int savecolor, row, col;
   int lolite;

   BRcell(int x, int y, int cellpix, int bg, int fg, int c, int r) : Fl_Box(x, y, cellpix, cellpix, 0) {
      col = c; row = r;
      box(FL_FLAT_BOX);
      labelsize(getiopt("cell_fs"));
      labelfont(FL_COURIER);
      color(lolite = bg);
      labelcolor(fg);
      align(FL_ALIGN_CENTER | FL_ALIGN_INSIDE);
   }
   int handle(int e) { cout << "BR handle" << endl; return Fl_Box::handle(e); }
};
class Brdcell : public BRcell {
   public:
   Brdcell(int cellpix, int x, int y, int r, int c)   : BRcell(cellpix * c + x, cellpix * r + y, cellpix, getiopt("cell_bg"), getiopt("cell_fg"), c, r) {}
   int handle(int);
};
class Rckcell : public BRcell {
   public:
   Rckcell(int x, int y, int cellpix, int c)          : BRcell(x, y, cellpix, getiopt("cell_bg"), getiopt("cell_fg"), c, 0) {}
   int handle(int);
};
class Brwsr : public Fl_Hold_Browser { // hold_browser item stays highlighted, select_browser item does not

   public:
   
   string lastsort;

   Brwsr(int x, int y, int w1, int w2, int h) : Fl_Hold_Browser(x, y, w1 + w2, h) {
      box(FL_FRAME_BOX);
      color(getiopt("list_bg"));
      textcolor(getiopt("list_fg"));
      textsize(18);
      static int bw[] = { w1, w2, 0 };
      column_widths(bw);
      callback(brwsr_cb);
      end();                                 // option lastsort is not used for init. the order after init will be the order on disk.
      lastsort = getsopt("lastsort");        // but sort_brwsr will use the lastsort property when user or code requests a (re)sort.
      if(lastsort.empty())
         lastsort = "4";
   }
   void load_first() {
   
      #define GMPTR ((game_s *) data(lineno(itm)))

      cout << "look for a game to show first" << endl;
      if(! item_first()) {
         cout << "game list is empty" << endl;                 // remaining code can assume list not empty
         return;
      }
      void     *itm = NULL;
      string   last = getsopt("lastgame");

      if(! last.empty()) {
         cout << "option lastgame is " << last << endl;        // try to match option last game with a menu item text. comparison is to oppname|starttm.
                              
         for(itm = item_first(); itm; itm = item_next(itm))
            if(! last.compare((string) GMPTR->opp + "|" + GMPTR->starttm))
               break;
         if(! itm)                                             // below code is about edge/error conditions
            cout << "game not found" << endl;
      }
      else
         cout << "last game option is empty" << endl;

      if(! itm) {
         cout << "look for first active game" << endl;
         for(itm = item_first(); itm; itm = item_next(itm))
            if(GMPTR->stat == GSACTV)
               break;
         if(! itm) {
            cout << "there are no active games" << endl;
            itm = item_first();
         }
      }
      select(lineno(itm));                                     // normal path resumes here
      load_game(GMPTR);
   }
   #undef GMPTR
};
class Msg : public Fl_Box {
   public:
   Msg(int x, int y) : Fl_Box(FL_FLAT_BOX, x, y, 10, LBLH, "Tylosaurus is kindly and will not eviscerate you!") {
      color(getiopt("msg_bg"));
      labelcolor(getiopt("msg_fg"));
      align(FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
   }
   void setmsg1() {
      game_s *gm = cur.game;
      string msgstr = STS(cur.nactv) + "/" + STS(cur.ngames) + " -- " + gm->opp + " -- " + gm->starttm + " ";
      if(gm->endtm[0])
         msgstr += "thru " + gm->endtm;
      copy_label(msgstr.c_str());
   }
};
class Notes : public Fl_Text_Editor {
   public:
   
   Notes(int x, int y, int w, int h) : Fl_Text_Editor(x, y, w, h) {
      box(FL_FRAME_BOX);
      textsize(getiopt("notes_fs"));
      color(getiopt("notes_bg"));
      textcolor(getiopt("notes_fg"));  
      cursor_color(getiopt("notes_cu"));
      wrap_mode(Fl_Text_Display::WRAP_AT_BOUNDS, 0);
      remove_key_binding(FL_Home,   FL_CTRL);                  // remap ctrl-home and ctrl-end to home and end
      remove_key_binding(FL_End,    FL_CTRL);
      add_key_binding   (FL_Home,   0,       kf_ctrl_move);
      add_key_binding   (FL_End,    0,       kf_ctrl_move);
      add_key_binding   (FL_Tab,    0,       kf_ignore);       // ignore but don't absorb tab
      add_key_binding   ('C',       FL_CTRL, kf_ignore);       // "     " ctrl- u.c and l.c. 'C'
      add_key_binding   ('c',       FL_CTRL, kf_ignore);
      end();
   }
   int handle(int e);
};

#include "tylo-table.h"    // need table.h between Notes class def and handle method until i figure out how to prototype

int Notes::handle(int e) {
   
   switch(e) {
      case FL_SHORTCUT:
         return EVNOTHANDLED;
      case FL_FOCUS:
         cout << "notes handle focus" << endl;
         this->show_cursor();
         return EVHANDLED;
      case FL_UNFOCUS:
         this->hide_cursor();
         return EVHANDLED;
      case FL_KEYBOARD:

         int k = Fl::event_key();
         int s = Fl::event_state();

         if(! (s & FL_ALT) && ! (s & FL_META)) {      // code is spread out b/c it may be expanded to cover more cases
            if(s & FL_CTRL) {
               if(! (s & FL_SHIFT)) {                    
                  switch(k) {
                     case FL_Delete :
                        this->buffer()->text(0);
                        return EVHANDLED;                // ctrl-delete is not a shortcut
                     case FL_End :
                        squish_mcb(nullptr, nullptr);    // this is a shortcut but brwsr vertical scrollbar, if present, will steal it
                        return EVHANDLED;
                     default:
                        return EVNOTHANDLED;
                  }
               }
            }
            else {
               if(s & FL_SHIFT) {
                  if(k == FL_Tab) {                   // shift-tab
                     cur.tbl->rck[0]->take_focus();
                     return EVHANDLED;
                  }
               }
            }
         }
   }
   // is any modified state possible here?
   return Fl_Text_Editor::handle(e);                  // let editor receive normal keystrokes
}
class Appmenu : public Fl_Menu_Bar {

   #define GAMENEW "&Game/&new"

   public:        // begin() and end() are not applicable in this ctor. ampersands create the Alt+ functionality.

   Appmenu(App *app) : Fl_Menu_Bar(0, 0, 10, 24) {

      // must clear submenu game/new despite there is nothing under it else i get a blank entry above the sub-sub-items when they are added.
      // also menu->user_data(app) doesn't work in this scenario. game/new is populated after read_tblinfo()
   
                           add(GAMENEW "/");          // must match exactly except for trailing '/'
      clear_submenu(find_index(GAMENEW));
      add("Game/save",              FL_CTRL +         's',  save_mcb,         app);
      add("Game/rematch",           FL_CTRL +         'm',  rematch_mcb,      app);
      add("Game/clear",             FL_CTRL +         '0',  clear_mcb,        app);
      add("Game/over",              FL_CTRL +         'o',  game_over_mcb,    app);
      add("Game/rename",            FL_CTRL +         'n',  rename_mcb,       app);
      add("Game/delete",            FL_CTRL +         'd',  delete_mcb,       app);
      add("Game/quit app",          FL_CTRL +         'q',  quit_mcb,         app);
      add("&Edit/copy rack",        FL_CTRL +         'c',  copyto_mcb,       app); // shared callback
      add("Edit/copy bag",          FL_CTRL +         'b',  copyto_mcb,       app);
      add("Edit/justify rack",      FL_CTRL + FL_End,       squish_mcb,       app);
      add("Edit/find letters",      FL_CTRL +         'f',  find_mcb,         app);
      add("Edit/reset find",        FL_CTRL + FL_ALT +'f',  find_reset_mcb,   app);
      add("&Sort/1. by name",          0,                   sort_mcb,         app); // shared
      add("Sort/2. by start",          0,                   sort_mcb,         app);
      add("Sort/3. by end",            0,                   sort_mcb,         app);
      add("Sort/4. by status by name", 0,                   sort_mcb,         app);
      add("&Help/help",                0,                   help_mcb,         app);
      add("Help/custom",            FL_CTRL +         'i',  cstm_mcb,         app);
      int index = find_index("&game/&new");    // get index of "File/Recent" submenu
      textcolor(FL_WHITE);
      color(0x2e3436 << 8);
      box(FL_FLAT_BOX);
   }
};
