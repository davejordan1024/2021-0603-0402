#include <iostream>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Button.H>
#include <FL/fl_ask.H>

using std::string;
using std::cout;
using std::endl;

// Pressing enter on Btn respects the marquee position

class Btn : public Fl_Button {
   public:
   Btn(int x, int y, int w, int h, const char *lbl) : Fl_Button(x, y, w, h, lbl){};
   int handle(int e);
};
int Btn::handle(int e) {
   if(e == FL_KEYBOARD && Fl::event_key() == FL_Enter) {
      cout << this->label() << endl;
      return 1;
   }
   return Fl_Button::handle(e);
}

class Dlg : public Fl_Window {

   public:
   Dlg(int x, int y, string msg = "", int nbtns = 0, int dflt = 0) : Fl_Window(x, y, 400, 400) {
      box(FL_DOWN_BOX);    
      Btn *b1 = new Btn(10, 10, 60, 20, "b1");
      Btn *b2 = new Btn(80, 10, 60, 20, "b2");
      Btn *b3 = new Btn(150, 10, 60, 20, "b3");
   }
};

int main() {

   Fl_Window *w = new Fl_Window(100, 100, 500, 500);
   Dlg *d = new Dlg(0, 0);
   w->show();
   Fl::run();
}
