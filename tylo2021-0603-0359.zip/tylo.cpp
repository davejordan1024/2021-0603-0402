#include "tylo.h"

class App : public Fl_Window {

   public:

   Appmenu  *menu;
   Fl_Box   *msg;
   Brwsr    *brwsr;
   Tbl      **tbls = nullptr;
   vector <game_s*> games;    // vector of pointers since games will be added and deleted in the normal course.

   ~App(){}
   App(int appx, int appy, int appw, int apph, cc *ttl) : Fl_Window(appx, appy, appw, apph, ttl) {

      int pad = getiopt("pad");
      int cellpix = getiopt("cellpix");
      int listw = getiopt("lw_opp") + getiopt("lw_time");

      begin();
      color(getiopt("app_bg"));

      cout << "create menu" << endl;
      if(! (menu = new nt Appmenu(this)))    // fill & tweak width below
         EOOM("menu");


      if(! (msg = new nt Msg(pad, menu->h())))  // tweak width below
         EOOM("message line");

      {  vector <tblinfo_s> tblinfo;                        // tblinfo can go away after this block
         read_tbl_info(tblinfo);

         int ntbls = tblinfo.size();                        // this is not the global cur.ntbls; that is reserved for after tbls are actually instantiated below
         if(! ntbls)
            EINIT("There is no table info in " TMPLTFL ".");

         int   tblx = 2 * pad + listw,    tbly = menu->h() + LBLH,
               tblw = 0,                  tblh = 0,
               brdbig, j;
      
         for(j = 0; j < ntbls; j++) {                                // find biggest dims, populate game/new submenu
            if(tblinfo[j].brdn > tblw)    tblw = tblinfo[j].brdn;
            if(tblinfo[j].alphan > tblh)  tblh = tblinfo[j].alphan;
            menu->add(((string) GAMENEW "/" + tblinfo[j].name).c_str(), 0, new_mcb, this);
         }
         brdbig = tblw;                                                          // brdbig gets biggest linear dim of board in cells
         tblw = pad + tblw * cellpix + pad + VISPIX + PVPIX + REMPIX + GVNPIX;   // tblw gets biggest width in pixels
         tblh = pad + (tblh + 3) * cellpix;                                      // tblh based on biggest alphan + 1 blank row + 3 (sub)total rows

         j = 0;
         int k = 0;
         if(! (tbls = new nt Tbl*[ntbls]))
            EOOM("tables pointers");
         for(tblinfo_s& it : tblinfo) {
            if(! (tbls[j++] = new nt Tbl(tblx, tbly, tblw, tblh, brdbig, it)))   // call table ctor
               EOOM("tables");
            if(cur.ntbls != ++k)                                  // cur.ntbls gets incremented if table ctor succeeds
               delete tbls[--k];                                  // reuse slot unless there arent any more tblinfos
         }
         tblinfo.clear();                                         // the members of the tblinfo vector arent pointers so clear() alone should do the trick.
                                                                  // below is a 2nd way there could be no tables (all tblinfo turned out to be bogus)
         if(cur.ntbls == 0)
            EINIT("There are no valid templates in " TMPLTFL ".");
      
         if(! (brwsr = new nt Brwsr(   pad,     msg->y() + msg->h(),    getiopt("lw_opp"),   getiopt("lw_time"),  tblh)))
            EOOM("browser");
         this->size(3 * pad + listw + tblw   ,  menu->h() + msg->h() + tblh + pad);    // tweak app dims
      }
      if(! read_games(this))
         throw(EXIT_FAILURE);

      menu->size(this->w(), menu->h());      // i can set certain widths now that i know this->w() aka app->w()
      msg->size(this->w(), msg->h());        // if msg->w() != enough, then msg->setmsg1() will not redraw label consistently
      callback(app_cb);                      // cb's only function is to intercept escape and the close button on the titlebar. actual code is just below.
      end();
   }  // end App constructor
};
void app_cb(Fl_Widget* app, void *v) {

   cout << "app callback" << endl;

   if(! (Fl::event() == FL_SHORTCUT && Fl::event_key() == FL_Escape)) { // ignore escape
      if(cur.mod) save((App *) app);                                    // save without asking. the menu cb quit_mcb() does ask.
      quit((App *) app);
   }
}
int main(int argc, char *argv[]) {

   cout     << APPTTL << ' ' << APPVER << '\n'
            << APPTTL << " is copyright 2021 by Dave Jordan and "
            "is based in part on the work of the FLTK project (http://www.fltk.org)." << "\n"
            << "FLTK ABI " << FL_ABI_VERSION << '\n'
            << "__cplusplus==" << __cplusplus << ", therefore std::filesystem facilities"
            #ifdef HAVEFS
               " will be used"
            #else
               " are not available"
            #endif
            << ".\n\ninit app" << endl;

   parse_arg0(argv[0]);
   read_opts();

   if(App *app = new nt App(getiopt("appx"), getiopt("appy"), 1, 1, APPTTL)) {
      if(cur.ngames) {
         app->brwsr->load_first();                                      // figure out which if any game to show first
         cur.tbl->brd[cur.tbl->brdn / 2][cur.tbl->brdn / 2]->take_focus();
      }
      setmod(app, false);
      cout << "init done" << endl;
      app->show();
      Fl::run();
      cout << "app window closed." << endl;
   }
   else EOOM("app");
}
#include "tylo-kbd_cb.h"
#include "tylo-funcs.h"
#include "tylo-menu.h"
#include "tylo-opts.h"
